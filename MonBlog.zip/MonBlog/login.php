<form action="index.php?action=login" method="POST">
    <input type="text" name="email" class="form__input" placeholder="email" required>
    <input type="password" name="password" class="form__input" placeholder="Password" required>
    <div>
        <input type="submit" value="Se connecter">
    </div>
</form>
<p><a href="register.php">S'inscrire maintenant</a></p>