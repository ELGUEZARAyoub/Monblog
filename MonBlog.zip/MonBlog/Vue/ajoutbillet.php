<div>

  <form  method="post" action="index.php?action=ajouter">

    <div>Titre: <input type="text" name="titre"></div>
    <textarea placeholder="Entrer votre blog." id="text" name="contenu" rows="4" style="overflow: hidden; word-wrap: break-word; resize: none; height: 160px; "></textarea>  
    <br>
    <input type="submit" value="Create">
    
  </form>

</div>
