<?php $titre = 'Mon Blog'; ?>

<p>Une erreur est survenue : <?= $msgErreur ?></p>
