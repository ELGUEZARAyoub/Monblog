<form action="index.php?action=register" method="POST">
    <input type="text" name="email" class="form__input" placeholder="email" required>
    <input type="text" name="username" class="form__input" placeholder="Username" required>
    <input type="password" name="password" class="form__input" placeholder="Password" required>
    <div>
        <input type="submit" value="S'inscrire">
    </div>
</form>
<p><a href="login.php">Se connecter</a></p>